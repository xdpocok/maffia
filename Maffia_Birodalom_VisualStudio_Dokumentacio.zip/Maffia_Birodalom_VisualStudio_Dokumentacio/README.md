# Maffia Birodalom - Játékdokumentáció

## Megnyitás Visual Studio / Visual Studio Code alatt

- Csomagold ki ezt a mappát.
- Nyisd meg a kicsomagolt mappát Visual Studio Code-ban vagy Visual Studióban.
- A fő dokumentáció itt található: `docs/01-jatek-koncepcio.md`.
- A fejlesztési feladatlista itt található: `docs/04-fejlesztesi-feladatlista.md`.
- A feltöltött játékfájl másolata itt található: `src/game.js`.

## Rövid leírás

- A játék címe: **Maffia Birodalom**.
- Műfaj: böngészős stratégiai maffiajáték.
- Hangulat: 1930-as évek, noir, városi bűnbirodalom, kerületek, rangok, család, befolyás.
- Szerkezeti irány: Goodgame Empire-szerű térképes birodalomépítés, de maffia témában.
- Fő cél: a játékos kis bandából indul, majd kerületeket, telkeket, üzleteket és ranglistát épít.

## Dokumentumok

- `docs/01-jatek-koncepcio.md`
  - Alapötlet, cél, hangulat, játékosfantázia.
- `docs/02-jatekmenet-rendszerek.md`
  - Core loop, gazdaság, akciók, rablás, védelmi pénz, küldetések.
- `docs/03-technikai-terv.md`
  - Jelenlegi kód iránya, fő modulok, mentés, adatok, javasolt fájlszerkezet.
- `docs/04-fejlesztesi-feladatlista.md`
  - Pontokra osztott fejlesztési terv MVP-től többjátékos irányig.
- `docs/05-adatok-es-egyensuly.md`
  - Kerületek, rangok, felszerelések, erőforrások, ajánlott számok.

## Ajánlott következő lépés

- Először a `docs/04-fejlesztesi-feladatlista.md` fájlt nyisd meg.
- Pipáld ki, mi van már kész.
- Utána a `src/game.js` fájlt lehet modulokra bontani.
