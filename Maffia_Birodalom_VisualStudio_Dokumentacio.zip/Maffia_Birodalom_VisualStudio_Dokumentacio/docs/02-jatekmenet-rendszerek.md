# 02 - Játékmenet és rendszerek pontokban

## 1. Core loop

- A játékos belép a játékba.
- Megnézi az aktuális állapotot:
  - pénz,
  - hírnév,
  - banda,
  - körözés,
  - életerő,
  - energia,
  - aktív küldetés.
- Választ egy célpontot a térképen.
- Akciót indít:
  - rablás,
  - védelmi pénz,
  - pihenés,
  - fejlesztés,
  - toborzás.
- Jutalmat kap vagy kockázatot szenved el.
- A megszerzett pénzt és hírnevet fejlesztésekre költi.
- A fejlődés új célpontokat és új rendszereket nyit meg.

## 2. Napi játékritmus

- Rövid belépés: 2-5 perc.
  - bevétel átvétele,
  - küldetés ellenőrzése,
  - 1-2 akció indítása.
- Közepes belépés: 10-15 perc.
  - több rablás,
  - felszerelés ellenőrzése,
  - telkek fejlesztése,
  - banda fejlesztése.
- Hosszabb belépés: 20+ perc.
  - térképes tervezés,
  - kerületfoglalás,
  - többjátékos ranglista figyelése,
  - gazdasági optimalizálás.

## 3. Fő erőforrások

- Pénz:
  - rablásból,
  - védelmi pénzből,
  - passzív bevételből,
  - küldetésekből szerezhető.
- Hírnév:
  - rangokat nyit,
  - kerületátvételhez kell,
  - ranglistán is fontos.
- Banda / crew:
  - akcióerőt ad,
  - kerületek megszerzéséhez kell,
  - harci minijátékban is szerepet kap.
- Körözés / heat:
  - túl sok bűnözés után nő,
  - magas értéknél nő a kockázat,
  - lapulással csökkenthető.
- Életerő:
  - rablásoknál csökkenhet,
  - pihenéssel töltődik vissza.
- Energia:
  - akciók költsége,
  - természetesen regenerálódik,
  - pihenéssel gyorsabban visszatölthető.

## 4. Akciók

- Rablás:
  - aktív kockázatos akció,
  - pénzt és hírnevet ad,
  - növeli a körözést,
  - sérülést okozhat.
- Védelmi pénz:
  - ismételhető, de cooldownhoz kötött,
  - kisebb kockázatú bevétel,
  - kerületekhez és épületekhez kapcsolható.
- Toborzás:
  - pénzbe és energiába kerül,
  - növeli a bandát,
  - növeli a hírnevet.
- Lapulás:
  - csökkenti a körözést,
  - cserébe időt vagy befolyást vesz el.
- Bázispihenés:
  - életerőt és energiát tölt vissza,
  - kezdő játékosoknál fontos túlélési funkció.
- Telekfejlesztés:
  - pénzbe kerül,
  - passzív bevételt ad,
  - később üzlettípusokra bontható.

## 5. Rablásos minijáték

- A rablás ne csak egy gombnyomás legyen.
- A játékos célpontot választ.
- A játék kiszámolja az ellenfél erejét.
- A játékos bandatagot vagy taktikát választ.
- A rablás során több érték változik:
  - játékos életereje,
  - kontroll,
  - alert,
  - ellenfél ereje,
  - zsákmány.
- Sikeres rablás esetén:
  - pénz jár,
  - hírnév jár,
  - küldetés haladhat,
  - tárgy is eshet.
- Sikertelen rablás esetén:
  - életerő csökken,
  - körözés nőhet,
  - pénzvesztés is lehet.

## 6. Küldetések

- A küldetésrendszer adja a játékosnak az irányt.
- Küldetéstípusok:
  - rablásos küldetés,
  - védelmi pénzes küldetés,
  - toborzós küldetés,
  - fejlesztési küldetés,
  - kerületfoglalási küldetés.
- A küldetés tartalmazza:
  - címet,
  - leírást,
  - célpontot,
  - állapotot,
  - célszámot,
  - haladást,
  - jutalmat.
- Jutalmak lehetnek:
  - pénz,
  - hírnév,
  - felszerelés,
  - energia,
  - bandatag bónusz.

## 7. Kerületkontroll

- A város kerületekre van osztva.
- Minden kerületnek saját értéke és biztonsága van.
- Minél nagyobb a biztonság, annál nehezebb átvenni.
- Kerületátvételhez kell:
  - megfelelő hírnév,
  - megfelelő bandaerő,
  - pénz vagy akciósorozat.
- Kontrollált kerület adhat:
  - napi bevételt,
  - hűséget,
  - befolyást,
  - új célpontokat.

## 8. Telkek és épületek

- A várostérképen üres telkek vannak.
- A telek fejleszthető.
- A telek szintje 0-ról indul.
- Lehetséges szintek:
  - 1. szint: kis üzlet,
  - 2. szint: kávézó vagy fedőüzlet,
  - 3. szint: díszes üzlet vagy családi fedővállalkozás.
- Minden szint több passzív bevételt ad.
- Később üzlettípusokra lehet bontani:
  - speakeasy bár,
  - illegális kaszinó,
  - autószerelő fedőműhely,
  - import raktár,
  - ruhaszalon,
  - informátor iroda.

## 9. Felszerelés

- Hat felszerelés slot ajánlott:
  - kalap,
  - ing,
  - nadrág,
  - fegyver,
  - cipő,
  - óra.
- Minden tárgy erőt ad.
- A fegyver nagyobb harci bónuszt ad.
- A ruházat stílust, presztízst vagy védelmet adhat.
- A tárgyak minősége:
  - alap,
  - ritka,
  - elit,
  - Don-szintű.

## 10. Rangok

- A rang a hírnév alapján nő.
- Ajánlott rangok:
  - Kezdő gengszter,
  - Utcai főnök,
  - Kerületvezető,
  - Befolyásos figura,
  - Maffia középvezető,
  - Maffia főnök,
  - Don,
  - Városi legenda.
- Minden rang nyithat:
  - új célpontot,
  - új tárgyakat,
  - magasabb épületszintet,
  - nagyobb bandalimietet,
  - új küldetéssort.
