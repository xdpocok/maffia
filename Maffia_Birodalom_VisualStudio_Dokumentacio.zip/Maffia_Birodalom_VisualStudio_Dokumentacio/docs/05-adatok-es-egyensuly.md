# 05 - Adatok és egyensúly pontokban

## 1. Kerületek

- Belváros
  - típus: központ
  - érték: közepes
  - biztonság: közepes
  - hangulat: régi házak, sűrű utcák, városi szív.
- Piac tér
  - típus: kereskedelem
  - érték: közepes
  - biztonság: közepes-alacsony
  - hangulat: üzletek, kirakatok, forgalmas sarkok.
- Kikötő
  - típus: logisztika
  - érték: magas
  - biztonság: közepes-magas
  - hangulat: raktárak, rakpart, teherautók.
- Gyárnegyed
  - típus: ipari zóna
  - érték: alacsony-közepes
  - biztonság: alacsony
  - hangulat: régi csarnokok, olcsó célpontok.
- Villanegyed
  - típus: prémium
  - érték: nagyon magas
  - biztonság: magas
  - hangulat: elegáns házak, nagy pénz, nagy kockázat.
- Peremkerület
  - típus: lakóövezet
  - érték: alacsony-közepes
  - biztonság: alacsony
  - hangulat: kisebb házak, kertek, könnyebb terjeszkedés.

## 2. Rangtábla

- Kezdő gengszter
  - szükséges hírnév: 0
  - nyitás: alap akciók.
- Utcai főnök
  - szükséges hírnév: 20
  - nyitás: jobb rablások.
- Kerületvezető
  - szükséges hírnév: 50
  - nyitás: kerületkontroll.
- Befolyásos figura
  - szükséges hírnév: 90
  - nyitás: fekete piac jobb ajánlatai.
- Maffia középvezető
  - szükséges hírnév: 150
  - nyitás: magasabb szintű üzletek.
- Maffia főnök
  - szükséges hírnév: 240
  - nyitás: erősebb banda és prémium célpontok.

## 3. Ajánlott erőforrás-skála

- Kezdő pénz: 100-150.
- Kezdő energia: 100.
- Kezdő életerő: 100.
- Kezdő banda: 3 ember.
- Kezdő körözés: 0.
- Könnyű rablás jutalom: 20-60 pénz.
- Közepes rablás jutalom: 70-160 pénz.
- Nehéz rablás jutalom: 180-400 pénz.
- Védelmi pénz: 25-120 pénz célponttól függően.
- Toborzás ára: 80-250 pénz.
- Telek első fejlesztése: 80 pénz körül.
- Telek második fejlesztése: 180 pénz körül.
- Telek harmadik fejlesztése: 320 pénz körül.

## 4. Felszerelés slotok

- Kalap
  - bónusz: stílus vagy presztízs.
  - példák: fekete fedora, selyemszalagos kalap, Don fedora.
- Ing
  - bónusz: fellépés vagy védelem.
  - példák: fehér ing, csíkos ing, selyeming.
- Nadrág
  - bónusz: rutin vagy védelem.
  - példák: fekete szövet, gyapjú nadrág, főnöki nadrág.
- Fegyver
  - bónusz: támadás.
  - példák: Colt M1911, rövid csövű puska, Tommy géppisztoly.
- Cipő
  - bónusz: lépés vagy lopakodás.
  - példák: bőr félcipő, csendes cipő, lakkcipő.
- Óra
  - bónusz: presztízs.
  - példák: zsebóra, ezüst óra, arany óra.

## 5. Bandatag szerepek

- Végrehajtó
  - kiegyensúlyozott támadás és életerő.
  - jó általános akciókra.
- Fegyveres
  - magas támadás.
  - jó rabláshoz és harci helyzetekhez.
- Megfigyelő
  - magasabb védelem vagy taktikai bónusz.
  - jó lopakodáshoz és előkészítéshez.

## 6. Körözés egyensúly

- Alacsony körözés: 0-25.
  - kevés extra kockázat.
- Közepes körözés: 26-60.
  - nagyobb rendőri figyelem.
- Magas körözés: 61-85.
  - rablásnál extra büntetés.
- Kritikus körözés: 86-100.
  - nagy bukási esély,
  - lapulás erősen ajánlott,
  - bizonyos akciók blokkolhatók.

## 7. Energia és regeneráció

- Energia akciónként fogyjon.
- Könnyű akció: 8-15 energia.
- Közepes akció: 16-30 energia.
- Nehéz akció: 31-50 energia.
- Természetes regeneráció:
  - lassú, időalapú.
  - teljes töltés 8-12 óra alatt ideális böngészős játékhoz.
- Pihenés:
  - gyorsabb visszatöltés.
  - cooldownhoz köthető.

## 8. Passzív bevétel

- Kerületbevétel:
  - érték x kontroll x hűség alapján számolható.
- Telekbevétel:
  - épületszint alapján számolható.
- Ajánlott napi telekbevétel:
  - 1. szint: 80.
  - 2. szint: 190.
  - 3. szint: 360.
- Fontos, hogy a passzív bevétel ne tegye feleslegessé az aktív játékot.
- A legjobb ritmus:
  - passzív bevétel segít,
  - aktív rablás gyorsít,
  - fejlesztés hosszú távon erősít.
