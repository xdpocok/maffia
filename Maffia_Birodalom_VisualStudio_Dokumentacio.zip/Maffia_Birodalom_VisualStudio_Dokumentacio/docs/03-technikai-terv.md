# 03 - Technikai terv pontokban

## 1. Jelenlegi technikai irány

- A játék JavaScript alapú böngészős prototípus.
- A kódban már szerepel:
  - mentési kulcs,
  - korábbi mentési verziók kezelése,
  - szerveres mentési API alapútvonal,
  - kerületdefiníciók,
  - rangtábla,
  - világtérkép generálás,
  - telekkoordináta-rendszer,
  - felszereléskatalógus,
  - bandatag sablonok,
  - kattintható épületek,
  - parkok,
  - üres telkek,
  - rablás UI elemek,
  - karakterpanel,
  - klánpanel,
  - ranglista panel,
  - fekete piac panel helye.

## 2. Javasolt projektstruktúra

- `index.html`
  - játék kezdő HTML fájl.
- `src/main.js`
  - indítás, fő inicializálás.
- `src/state.js`
  - játékállapot.
- `src/save.js`
  - mentés és betöltés.
- `src/config/districts.js`
  - kerületek.
- `src/config/ranks.js`
  - rangok.
- `src/config/equipment.js`
  - felszerelések.
- `src/config/buildings.js`
  - kattintható városi épületek.
- `src/config/lots.js`
  - telkek és fejlesztések.
- `src/systems/economy.js`
  - pénz, bevétel, költségek.
- `src/systems/quests.js`
  - küldetések.
- `src/systems/robbery.js`
  - rablásos minijáték.
- `src/systems/worldMap.js`
  - világtérkép és telekválasztás.
- `src/ui/hud.js`
  - HUD frissítés.
- `src/ui/panels.js`
  - oldalpanelek.
- `src/ui/modals.js`
  - modális ablakok.
- `assets/`
  - képek, térképek, karakterek, ikonok.
- `docs/`
  - játékdokumentáció.

## 3. Állapotkezelés

- A játékállapot legyen egy központi objektumban.
- Fontos állapotmezők:
  - profilnév,
  - pénz,
  - hírnév,
  - banda,
  - körözés,
  - életerő,
  - energia,
  - felszerelés,
  - inventár,
  - bandatagok,
  - aktív bandatag,
  - kiválasztott telek,
  - városi telkek fejlesztése,
  - kerületek kontrollja,
  - aktív küldetések,
  - cooldownok,
  - napi limitek.

## 4. Mentés

- Lokális mentés:
  - `localStorage` használata.
  - verziózott mentési kulcsok.
  - régi mentések beolvasása.
- Szerveres mentés:
  - `/api/saves` végpont.
  - profilnév alapján játékosazonosítás.
  - ranglista és világtérkép miatt később kötelező.
- Mentési szabály:
  - fontos akció után azonnal mentés,
  - gyors egymásutáni akcióknál késleltetett mentés,
  - hibás szerverválasz esetén lokális mentés maradjon.

## 5. Világtérkép technika

- A világtérkép csempézett háttérből áll.
- A térkép mérete több csempe összege.
- A telkek generálhatók sorok és oszlopok alapján.
- Minden telek kap:
  - azonosítót,
  - kódot,
  - koordinátát,
  - x pozíciót,
  - y pozíciót.
- A játékos kezdéskor szabad telket választ.
- Foglalt telek nem választható.
- Saját telek külön jelölést kap.

## 6. UI-rendszer

- A HUD mindig mutassa:
  - pénz,
  - hírnév,
  - rang,
  - banda,
  - körözés,
  - életerő,
  - energia,
  - aktív küldetés.
- A térképen kattintható elemek legyenek.
- Kattintáskor választókerék vagy panel jelenjen meg.
- Fontos panelek:
  - karakterlap,
  - felszerelésválasztó,
  - rablás minijáték,
  - telekinformáció,
  - ranglista,
  - klán,
  - fekete piac,
  - világtérkép.

## 7. Adatvezérelt fejlesztés

- A játék elemei ne legyenek szétszórva a kódban.
- Kerületek külön config fájlban legyenek.
- Rangok külön config fájlban legyenek.
- Felszerelések külön config fájlban legyenek.
- Küldetések sablonokból generálódjanak.
- Így könnyebb lesz:
  - új tárgyat hozzáadni,
  - új kerületet hozzáadni,
  - egyensúlyt módosítani,
  - új küldetést írni,
  - később adatbázisba áttenni.

## 8. Fontos minőségi feladatok

- A teljes szöveg legyen magyar ékezetes.
- A hibás karakterkódolásokat javítani kell.
- A fájlokat érdemes UTF-8 kódolással menteni.
- A túl hosszú `game.js` fájlt modulokra kell bontani.
- A megjelenítést és a logikát külön kell választani.
- A mentés előtt az adatokat normalizálni kell.
- A játékállapot ne sérüljön hibás mentésnél.
- Mobilnézetnél a térkép helyett egyszerűsített panel is kellhet.
