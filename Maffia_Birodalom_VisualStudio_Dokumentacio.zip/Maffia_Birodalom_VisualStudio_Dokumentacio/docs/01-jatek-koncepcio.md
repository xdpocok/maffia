# 01 - Játék koncepció pontokban

## 1. Alapötlet

- A játék neve: **Maffia Birodalom**.
- Böngészőben futó stratégiai játék.
- A játékos egy 1930-as évekbeli városban épít bűnbirodalmat.
- A játékos kezdetben kis bandavezér.
- A cél a város kerületeinek megszerzése.
- A fejlődés pénzből, hírnévből, felszerelésből, bandatagokból és területből áll.
- A játék hosszú távon többjátékos ranglistára és világtérképre épülhet.

## 2. Hangulat

- 1930-as évek.
- Noir városkép.
- Esős utcák.
- Téglaházak.
- Régi autók.
- Füstös bárok.
- Sötét sikátorok.
- Elegáns, de veszélyes maffiavilág.
- Színek:
  - barna,
  - bézs,
  - fekete,
  - sötétszürke,
  - arany,
  - vörös kiemelések.

## 3. Játékosfantázia

- A játékos nem csak egy karaktert irányít.
- A játékos egy teljes maffiacsaládot épít.
- A cél, hogy az utcai gengszterből Don legyen.
- A játékos dönt:
  - kit rabol ki,
  - hol szed védelmi pénzt,
  - mikor fejleszt,
  - mikor lapul,
  - melyik kerületet akarja megszerezni,
  - milyen felszerelést használ,
  - melyik bandatagot küldi akcióba.

## 4. Goodgame Empire-szerű irány

- Nem a téma hasonló, hanem a szerkezet.
- Hasonló elemek:
  - térképes világ,
  - területfoglalás,
  - fejlődő bázis,
  - erőforrás-termelés,
  - ranglista,
  - időalapú fejlődés,
  - játékosok közötti verseny,
  - több terület kezelése.
- Maffia témára átültetve:
  - kastély helyett családi bázis,
  - katonák helyett bandatagok,
  - nyersanyagok helyett pénz, hírnév, befolyás,
  - csaták helyett rablások, leszámolások, védelmi pénz,
  - tartományok helyett városi kerületek.

## 5. Fő célok

- Rövid távú cél:
  - pénz szerzése,
  - hírnév növelése,
  - banda erősítése,
  - kezdő küldetések teljesítése.
- Középtávú cél:
  - telkek fejlesztése,
  - jobb felszerelés megszerzése,
  - nehezebb célpontok legyőzése,
  - kerületkontroll növelése.
- Hosszú távú cél:
  - városi dominancia,
  - világtérképes bázis fejlesztése,
  - ranglistahelyezés,
  - más játékosokkal való verseny,
  - klán/család rendszer.

## 6. Célközönség

- Böngészős stratégiai játékokat kedvelő játékosok.
- Goodgame Empire-szerű fejlődést szerető játékosok.
- Maffia/noir témát kedvelő játékosok.
- Olyan játékosok, akik szeretnek naponta többször rövid időre belépni.
- Olyan játékosok, akik szeretik a ranglistát és a lassú, hosszú távú fejlődést.

## 7. Platform

- Első verzió:
  - PC böngésző,
  - egérrel használható térkép,
  - HTML, CSS, JavaScript.
- Második verzió:
  - mobilbarát nézet,
  - nagyobb gombok,
  - egyszerűbb térképkezelés.
- Későbbi lehetőség:
  - PWA,
  - telepíthető webapp,
  - szerveres profilmentés,
  - online ranglista.
