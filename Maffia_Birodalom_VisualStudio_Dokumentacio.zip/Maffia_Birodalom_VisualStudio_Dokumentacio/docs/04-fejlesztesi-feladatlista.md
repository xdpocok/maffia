# 04 - Fejlesztési feladatlista pontokban

## 1. Azonnali rendrakás

- [ ] A teljes projektet mappákba rendezni.
- [ ] A `game.js` fájlt átnevezni vagy modulokra bontani.
- [ ] A karakterkódolási hibákat javítani.
- [ ] A magyar ékezeteket egységesíteni.
- [ ] A config adatokat külön fájlokba rakni.
- [ ] A UI szövegeket külön nyelvi fájlba rakni.
- [ ] A mentési verziószámot dokumentálni.
- [ ] A hibakezelést láthatóbbá tenni.

## 2. MVP - játszható első verzió

- [ ] Regisztráció profilnévvel.
- [ ] Kezdő világtérképes telekválasztás.
- [ ] Várostérkép megjelenítése.
- [ ] Épületre kattintás.
- [ ] Rablás indítása.
- [ ] Védelmi pénz indítása.
- [ ] Energia és életerő fogyasztás.
- [ ] Pénz és hírnév jutalom.
- [ ] Körözés növekedés.
- [ ] Lapulás funkció.
- [ ] Pihenés funkció.
- [ ] Napi bevétel.
- [ ] Legalább 5 küldetés.
- [ ] Legalább 6 rang.
- [ ] Legalább 6 felszerelés slot.
- [ ] Mentés és betöltés.
- [ ] Alap ranglista.

## 3. Gazdaság fejlesztése

- [ ] Telek megvásárlás vagy elfoglalás.
- [ ] Telek fejlesztése 1-3 szintig.
- [ ] Passzív bevétel számítása.
- [ ] Kerületbevétel bevezetése.
- [ ] Hűség vagy kontroll érték bevezetése.
- [ ] Külön üzlettípusok.
- [ ] Külön költségek üzlettípusonként.
- [ ] Bevétel begyűjtés gomb.
- [ ] Napi limit vagy időalapú termelés.

## 4. Harc és rablás

- [ ] Célpont nehézségének pontos skálázása.
- [ ] Bandatagok szerepének erősítése.
- [ ] Taktikaválasztás hatásainak pontosítása.
- [ ] Ellenféltípusok bevezetése.
- [ ] Loot táblázat.
- [ ] Ritka tárgy esés.
- [ ] Rablás utáni összefoglaló panel.
- [ ] Sikertelen rablás következményei.
- [ ] Magas körözés esetén extra rendőri kockázat.

## 5. Küldetésrendszer

- [ ] Küldetéssablonok létrehozása.
- [ ] Küldetés generálása kerület alapján.
- [ ] Napi küldetések.
- [ ] Főküldetés-sorozat.
- [ ] Ranghoz kötött küldetések.
- [ ] Jutalmak kiegyensúlyozása.
- [ ] Küldetésnapló.
- [ ] Teljesített küldetések listája.

## 6. Karakter és banda

- [ ] Bandatag szintlépés.
- [ ] Bandatag támadás, védelem, életerő fejlesztése.
- [ ] Új bandatagok toborzása.
- [ ] Ritka bandatagok.
- [ ] Bandatag sérülés vagy pihenőidő.
- [ ] Aktív bandatag kiválasztása akció előtt.
- [ ] Karakter statisztika részletesítése.
- [ ] Felszerelés összehasonlító panel.

## 7. Fekete piac

- [ ] Fegyverek vásárlása.
- [ ] Ruházat vásárlása.
- [ ] Informátor vásárlása.
- [ ] Hamis papírok vásárlása.
- [ ] Körözéscsökkentő szolgáltatás.
- [ ] Ritka napi ajánlatok.
- [ ] Korlátozott készlet.
- [ ] Árskálázás rang alapján.

## 8. Világtérkép és többjátékos irány

- [ ] Foglalt telkek szerverről betöltése.
- [ ] Más játékos adatainak megjelenítése.
- [ ] Saját külső bázis fejlesztése.
- [ ] Bázisszint látható ikonja.
- [ ] Világtérképes kereső finomítása.
- [ ] Játékos profilkártya más telkére kattintva.
- [ ] Ranglista város, hírnév és bázisszint alapján.
- [ ] Később támadás más játékos ellen.
- [ ] Később szövetség / család rendszer.

## 9. UI és grafika

- [ ] Egységes 1930-as évekbeli gombstílus.
- [ ] Dosszié jellegű panelek.
- [ ] Animált térkép hover.
- [ ] Jobb karakterportré.
- [ ] Tárgyikonok.
- [ ] Kerületikonok.
- [ ] Rablás eredmény animáció.
- [ ] Hangulatüzenetek.
- [ ] Mobilbarát HUD.
- [ ] Egységes betűtípus.

## 10. Tesztelés

- [ ] Új játék indítása teszt.
- [ ] Mentés-betöltés teszt.
- [ ] Régi mentés kompatibilitás teszt.
- [ ] Rablás siker teszt.
- [ ] Rablás bukás teszt.
- [ ] Energia 0 teszt.
- [ ] Életerő 0 teszt.
- [ ] Körözés maximum teszt.
- [ ] Telekfejlesztés teszt.
- [ ] Világtérképes telekválasztás teszt.
- [ ] Ranglista betöltés teszt.

## 11. Kiadási terv

- [ ] 0.1 verzió: prototípus stabilizálása.
- [ ] 0.2 verzió: játszható core loop.
- [ ] 0.3 verzió: küldetések és felszerelés bővítése.
- [ ] 0.4 verzió: gazdaság és telkek.
- [ ] 0.5 verzió: ranglista és szerveres mentés.
- [ ] 0.6 verzió: világtérkép fejlesztése.
- [ ] 0.7 verzió: klán/család rendszer alapjai.
- [ ] 1.0 verzió: publikus első kiadás.
